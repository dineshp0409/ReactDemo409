insert into transaction(id, description, total, customer_id) values (1001, 'Purchase 1', 100, "CUSTOMER 1");
insert into transaction(id, description, total, customer_id) values (1002, 'Purchase 2', 50, "CUSTOMER 1");
insert into transaction(id, description, total, customer_id) values (1003, 'Purchase 3', 120,"CUSTOMER 1");

insert into transaction(id, description, total, customer_id) values (1200, 'Purchase 1', 25.60, "CUSTOMER 2");
insert into transaction(id, description, total, customer_id) values (1201, 'Purchase 2', 80.50, "CUSTOMER 2");
insert into transaction(id, description, total, customer_id) values (1202, 'Purchase 3', 116.14, "CUSTOMER 2");

insert into transaction(id, description, total, customer_id) values (1008, 'Purchase 1', 200, "CUSTOMER 3");